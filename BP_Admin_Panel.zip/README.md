# Best Practicify
This is a simple react application including dashboard for best practicify.In this project we have create the app using create-react-app. Here, We have use Ract Redux for app state management and context for layout state management only and React Material UI for design. 

# key Feature

# Technology 
1. React
2. React Redux
3. React Context
4. React Material Ui

## setup instruction 

1. Follow the command for development server

    `npm install --only=dev`
    `npm install`
    `npm start`
    
2. dont forget to creat a .env file. follow the .env.example file constatnt structure

Note: due to a package installation problem I have added npm-force-resolutions to dev dependecy. 

## List of url for admin
const structure = [
1 { label: "Dashboard", link: "/admin"},
2 { label: "Basic Info", link: "/admin/homepage" },
3 { label: "Slider", link: "/admin/homePageSlider" },
4 { label: "Short Intro", link: "/admin/shortIntro" },
5 { label: "Walk-through", link: "/admin/homePageFunctionAreaDetail" },
6 { label: "Consulting", link: "/admin/homeConsultationTopic" },
7 { label: "Core Values", link: "/admin/homePageCoreValueDetail" },
8 { label: "Modern Tech", link: "/admin/modernTechDetail" },
9 { label: "Personalized Service Detail", link: "/admin/personalizedServiceDetail" },
10{ label: "Unique Solution Detail", link: "/admin/uniqueSolutionDetail" },
11{ label: "Menu", link: "/admin/menu" },
12{ label: "Menu Section", link: "/admin/menuSection" },
13{ label: "Menu Section Details", link: "/admin/menuSectionDetail" },
14{ label: "Menu Hero Slider", link: "/admin/menuHeroSlider" },
15{ label: "Submenu", link: "/admin/submenu" },
16{ label: "Submenu Best Practice", link: "/admin/submenuBestPractice" },
17{ label: "SubMenu Overview", link: "/admin/subMenuOverView" },
18{ label: "SubMenu Business Context", link: "/admin/subMenuBusinessContext" },
19{ label: "Menu SubMenu Map", link: "/admin/menuSubMenuMap" },
20{ label: "Menu Sub Menu Map Detail", link: "/admin/menuSubMenuMapDetail" },
21{ label: "Menu SubMenu Map Item", link: "/admin/menuSubMenuMapItem" },
22{ label: "Menu Sub Menu Map Item List Item", link: "/admin/menuSubMenuMapItemListItem" },
23{ label: "Training Detail", link: "/admin/trainingDetail"},
24{ label: "Testimonial Detail", link: "/admin/testimonialDetail"},
25{ label: "Footer Section", link: "/admin/footerSection"},
26{ label: "Blog Post", link: "/admin/blogPost" },
27{ label: "Blog Category", link: "/admin/blogCategory" },
28{ label: "Blog Sub Category", link: "/admin/blogSubCategory" },
29{ label: "Role", link: "/admin/role" },
30{ label: "Users", link: "/admin/user" },
31{ label: "Resource", link: "/admin/resource" },
32{ label: "Role Resource", link: "/admin/roleResource" },
33{label: "Cta Category",link: "/admin/ctaCategory"},
34{label: "Contact Us",link: "/admin/contactUs"},
35{label: "Payment Package",link: "/admin/paymentPackage"},
];


menu - select category
submenu select function


