export  const  ResponseMessage = {
    'errorDeleteMessage' : "Delete is not possible",
    'successSaveMessage' : 'Submission Successful'
}