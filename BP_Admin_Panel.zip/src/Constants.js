export const BASE_API_URL="https://bp.sobjibazaar.com/api/"
export const BASE_URL="https://bp.sobjibazaar.com/"
