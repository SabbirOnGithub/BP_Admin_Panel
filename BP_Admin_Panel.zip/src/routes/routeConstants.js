export const accessDeniedRoute = '/admin/accessDenied';

 