export const Software_LIST_REQUEST = "Software_LIST_REQUEST";
export const Software_LIST_SUCCESS = "Software_LIST_SUCCESS";
export const Software_LIST_FAIL = "Software_LIST_FAIL";

export const Software_DETAILS_REQUEST = "Software_DETAILS_REQUEST";
export const Software_DETAILS_SUCCESS = "Software_DETAILS_SUCCESS";
export const Software_DETAILS_FAIL = "Software_DETAILS_FAIL";

export const Software_SAVE_REQUEST = "Software_SAVE_REQUEST";
export const Software_SAVE_SUCCESS = "Software_SAVE_SUCCESS";
export const Software_SAVE_FAIL = "Software_SAVE_FAIL";

export const Software_DELETE_REQUEST = "Software_DELETE_REQUEST";
export const Software_DELETE_SUCCESS = "Software_DELETE_SUCCESS";
export const Software_DELETE_FAIL = "Software_DELETE_FAIL";

  